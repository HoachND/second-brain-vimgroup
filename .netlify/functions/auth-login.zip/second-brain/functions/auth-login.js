var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// functions/_auth.js
var require_auth = __commonJS({
  "functions/_auth.js"(exports2, module2) {
    var crypto2 = require("crypto");
    function json2(statusCode, body) {
      return { statusCode, headers: { "content-type": "application/json", "cache-control": "no-store" }, body: JSON.stringify(body) };
    }
    function getCookie(event, name) {
      const raw = event.headers?.cookie || event.headers?.Cookie || "";
      for (const part of raw.split(";")) {
        const [k, ...rest] = part.trim().split("=");
        if (k === name) return decodeURIComponent(rest.join("="));
      }
      return "";
    }
    function sign(value) {
      const secret = process.env.SB_AUTH_SECRET;
      if (!secret || secret.length < 24) return "";
      return crypto2.createHmac("sha256", secret).update(value).digest("hex");
    }
    function requireAuth(event) {
      const secret = process.env.SB_AUTH_SECRET;
      if (!secret || secret.length < 24) return { ok: false, response: json2(503, { ok: false, error: "server auth not configured" }) };
      const token = getCookie(event, "sb_session");
      if (!token || !token.includes(".")) return { ok: false, response: json2(401, { ok: false, error: "auth required" }) };
      const [value, sig] = token.split(".", 2);
      if (!value || !sig || sign(value) !== sig) return { ok: false, response: json2(401, { ok: false, error: "auth required" }) };
      return { ok: true };
    }
    function makeSession2() {
      const value = crypto2.randomBytes(24).toString("hex");
      return `${value}.${sign(value)}`;
    }
    module2.exports = { json: json2, requireAuth, makeSession: makeSession2 };
  }
});

// functions/auth-login.js
var { json, makeSession } = require_auth();
var crypto = require("crypto");
function sha256(s) {
  return crypto.createHash("sha256").update(String(s || "")).digest("hex");
}
exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return json(405, { ok: false, error: "Method Not Allowed" });
  try {
    const configured = process.env.SB_LOGIN_PASSWORD_SHA256;
    if (!configured || configured.length < 32) return json(503, { ok: false, error: "server auth not configured" });
    const body = JSON.parse(event.body || "{}");
    const pass = String(body.password || "").trim();
    if (!pass || sha256(pass) !== configured) return json(401, { ok: false, error: "invalid password" });
    return {
      statusCode: 200,
      headers: {
        "content-type": "application/json",
        "cache-control": "no-store",
        "set-cookie": `sb_session=${makeSession()}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=2592000`
      },
      body: JSON.stringify({ ok: true })
    };
  } catch (e) {
    return json(500, { ok: false, error: String(e && e.message || e) });
  }
};
